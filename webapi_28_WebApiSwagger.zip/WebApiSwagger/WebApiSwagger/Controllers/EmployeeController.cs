﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiSwagger.Controllers
{
    [Route("api/emp")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        List<Employee> employees = new List<Employee>()
        {
            new Employee(){Id=101,Name="Poovendhran",Location="Chennai",Salary=50000},
            new Employee(){Id=102,Name="Kumudhini",Location="Chennai",Salary=26000 },
            new Employee(){Id=103,Name="Priya",Location="Pune",Salary=30000},
            new Employee(){Id=104,Name="Vengatesh",Location="Kochi",Salary=80000}
        };

        [HttpGet]
        public IEnumerable<Employee> get()
        {
            return employees;
        }

    }
}
