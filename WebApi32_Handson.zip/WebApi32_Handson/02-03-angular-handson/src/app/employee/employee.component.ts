import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  title = "Employee Information";
  name = "Poovendhran";
  salary = 25000;
  joiningDate = new Date("2021/12/28");
}
